//
//  DaysCell.swift
//  BeFit
//
//  Created by Saloni Parekh on 2018-08-13.
//  Copyright © 2018 Saloni Parekh. All rights reserved.
//

import UIKit

class DaysCell: UICollectionViewCell {
 
    
    @IBOutlet weak var lblDays: UILabel!
    
    
    @IBOutlet weak var lblDesc: UILabel!
    
    @IBOutlet weak var imgDays: UIImageView!
}
