//
//  DaysItems.swift
//  BeFit
//
//  Created by Saloni Parekh on 2018-08-13.
//  Copyright © 2018 Saloni Parekh. All rights reserved.
//

import Foundation
class DaysItems{
    static var days : [String] = ["day1", "day2", "day3", "day4"]
    static var desc : [String] = ["This is the tutorial for the beginners which includes exercises to be followed in the INITIAL DAYS of the BE FIT PROGRAM", "This includes exercises which are to be done on daily basis of the schedule", "The videos included in this session levels up the BE FIT challenge", "The tutorial here includes the videos which should be continued later on..."]
}
