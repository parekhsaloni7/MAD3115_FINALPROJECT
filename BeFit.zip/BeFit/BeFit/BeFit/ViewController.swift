//
//  ViewController.swift
//  BeFit
//
//  Created by MacStudent on 2018-08-10.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var txtUserID: UITextField!
    
    
    @IBOutlet var txtPassword: UITextField!
    
    
    @IBAction func btnSignUp(_ sender: UIButton) {
    }
    
    
    @IBAction func btnLogin(_ sender: UIButton) {
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

