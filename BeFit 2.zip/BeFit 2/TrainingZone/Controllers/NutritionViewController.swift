
import UIKit

class NutritionViewController: UIViewController {


    
    override func viewDidLoad() {
        super.viewDidLoad()



    }

}
