import UIKit

class AllExercisesViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UISearchBarDelegate  {
   
    

    @IBOutlet weak var exercisesCollectionView: UICollectionView!
    
    
    var searchActive : Bool = false
    var data = ["Muscle: Chest","Muscle: Back","Muscle: Triceps","Muscle: Biceps","Muscle: Legs","Muscle: Abs"]
    var filtered:[String] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        exercisesCollectionView.dataSource = self
        exercisesCollectionView.delegate = self
        //Search.delegate = self
        
    }
//  func searchBarTextDidBeginEditing(searchBar: UISearchBar) {
//        searchActive = true;
//    }
//
//    func searchBarTextDidEndEditing(searchBar: UISearchBar) {
//        searchActive = false;
//    }
//
//    func searchBarCancelButtonClicked(searchBar: UISearchBar) {
//        searchActive = false;
//    }
//
//    func searchBarSearchButtonClicked(searchBar: UISearchBar) {
//        searchActive = false;
//    }
//
//    func searchBar(searchBar: UISearchBar, textDidChange searchText: String) {
//
//        filtered = data.filter({ (text) -> Bool in
//            let tmp: NSString = text as NSString
//            let range = tmp.range(of: searchText, options: NSString.CompareOptions.caseInsensitive)
//            return range.location != NSNotFound
//        })
//        if(filtered.count == 0){
//            searchActive = false;
//        } else {
//            searchActive = true;
//        }
//        self.exercisesCollectionView.reloadData()
//    }


    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return Model.allExercises.count
    }
 
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let cell = exercisesCollectionView.dequeueReusableCell(withReuseIdentifier: "AllExercisesCell", for: indexPath) as? ExerciseCell {
            let exercise = Model.allExercises[indexPath.row]
            cell.updateViews(exercise: exercise )
            return cell
        }
        return ExerciseCell()
        
    }

    @IBOutlet weak var txtFieldSearchBar: UITextField!
    
    @IBAction func btnSearch(_ sender: Any) {
        var search = txtFieldSearchBar.text!
        
        
    }

    }

extension AllExercisesViewController: UITextFieldDelegate {
    
    
    public func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let substring = (textField.text! as NSString).replacingCharacters(in: range, with: string)
      
        
        return true
        
    }}
