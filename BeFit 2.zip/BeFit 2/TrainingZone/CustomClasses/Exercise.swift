import UIKit

class Exercise
{
    private var name : String
    private var muscle : String
    private var imageName : String
    //
    
    
    init(_ aName: String, _ aMuscle:String, _ anImageName: String)
    {
        name = aName
        muscle = aMuscle
        imageName = anImageName
        
    }
    
    
    func getName() -> String
    {
        return name
    }
    
    func getMuscle() -> String
    {
        return muscle
    }
    
    func getImageName() -> String
    {
        return imageName
    }
    
    
    
}
