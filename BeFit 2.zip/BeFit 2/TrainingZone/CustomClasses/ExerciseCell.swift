

import UIKit

class ExerciseCell: UICollectionViewCell {
    
    
    @IBOutlet weak var exerciseImage: UIImageView!
    @IBOutlet weak var muscleLabel: UILabel!
    @IBOutlet weak var nameLabel: UILabel!
    
    func updateViews(exercise: Exercise) {
        exerciseImage.image = UIImage(named: exercise.getImageName())
        muscleLabel.text = "Muscle: \(exercise.getMuscle()) "
        nameLabel.text = exercise.getName()
        
    }
}
