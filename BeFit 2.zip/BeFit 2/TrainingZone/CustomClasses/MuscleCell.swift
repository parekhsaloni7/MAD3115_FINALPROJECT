
import UIKit

import UIKit

class MuscleCell: UITableViewCell {
    


    @IBOutlet weak var muscleImage: UIImageView!
    
    @IBOutlet weak var muscleTitle: UILabel!
    
    func updateView(muscle: Category) {
        muscleImage.image = UIImage(named: muscle.imageName)
        muscleTitle.text = muscle.title
    }
    
    
    
}

